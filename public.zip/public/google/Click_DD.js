var getScriptPromisify = (src) => {
    return new Promise(resolve => {
      $.getScript(src, resolve)
    })
  }
  
  (function () {
  
    //Chart Block in HTML
    const prepared = document.createElement('template')
    prepared.innerHTML = `<head>
    <style>
    ul, #myUL
    {
        list-style-type: none;
    }
     
    #myUL
    {
        margin: 0;
        padding: 0;
    }
     
    .box
    {
        cursor: pointer;
        font-size:20px;
    }
     
    .box::before
    {
        content:"+";
        color: black;
        display: inline-block;
        margin-right: 6px;
    }
     
    .check-box::before
    {
        content: "-";
    }
     
    .nested
    {
        display: none;
    }
     
    .active
    {
        display: block;
    }
    </style>
    
    </head>
    <body>
  
      <div id="myUL" style="overflow: auto; height: 700px;">
  
      </div>
  
    </body>
      `
  
    //Main JS Class holds methods to be called
    class SamplePrepared extends HTMLElement {
      constructor() { 
  
        //call SAC DOM Super method to get shadow DOM information
        super()
  
        //Get shadow DOM informations
        this._shadowRoot = this.attachShadow({ mode: 'open' })
        this._shadowRoot.appendChild(prepared.content.cloneNode(true))
  
        //Set HTML block in shadow DOM of SAC
        this._root = this._shadowRoot.getElementById('myUL')
        //_props object is used to hold properties information
        this._props = {}
  
        //Call render() method to plot chart
        this.render(this.resultSet)
      }
  
      //onCustomWidgetResize() method is execute whenever CW will resized in SAC.
      onCustomWidgetResize(width, height) {
  
        //Call render() method to plot chart
        this.render(this.resultSet)
      }
  
      //render() method to plot chart - resultSet1 holds data from SAC table/chart.
      async render(_resultSet) {
  
        // console.log(_resultSet);
        
        var a = this._shadowRoot.getElementById('myUL');
        a.innerHTML = '';
        
        var class1 = 'class = "box"';
        var class2 =  'class = "nested"';
        
        var HTML = '';
        var count = 0;
  
        for(var i = 0; i < 18; i++)
        {
          // class1 = '';
          // sty = '';
          // if(_resultSet[i].l === '0'){
          //   var type = '<b><i>';
          //   class1 = 'class = "box"';
          // }else if(_resultSet[i].l === '1'){
          //   var type = '<i>';
          //   class1 = 'class = "box"';
          // }else if(_resultSet[i].l === '2'){
          //   var type = '<b>';
          //   class1 = 'class = "nested"';
  
          // }else {
          //   var type = '';
          // }
  
          // const prepared1 = document.createElement('li')
          // prepared1.innerHTML = ''+
          //   '<span id=' + _resultSet[i].name +' '+class1+' >' + type + _resultSet[i].name + '</span>'
  
          // a.appendChild(prepared1);
  
          while(parseInt(_resultSet[i].l) <= parseInt(_resultSet[i+1].l) && i < 18){
  
            if(parseInt(_resultSet[i].l) < parseInt(_resultSet[i+1].l)){
  
              HTML = HTML +' '+_resultSet[i].ul+'<li><span id=' + i.toString() +' '+class1+'>' + _resultSet[i].name + '</span>'
              count++;
            
            }else if(parseInt(_resultSet[i].l) === parseInt(_resultSet[i+1].l)){
  
              HTML = HTML +' '+_resultSet[i].ul+'<li><span id=' + i.toString()+'>' + _resultSet[i].name + '</span></li>'
            }
  
              i++;
          }
  
          if(parseInt(_resultSet[i-1].l) < parseInt(_resultSet[i].l)){
          HTML = HTML +' '+_resultSet[i].ul+'<li ' + class2 + '><span id=' + i.toString() +'>' + _resultSet[i].name + '</span></li>'
          }else{
            HTML = HTML +' '+_resultSet[i].ul+'<li><span id=' + i.toString() +'>' + _resultSet[i].name + '</span></li>'
          }
  
        var noul = count - parseInt(_resultSet[i+1].l);
  
        // for(var k = 1; k <= noul;k++){
        //   HTML = HTML +' '+ '</li></ul>'
        //   count--;
        // }
  
        }
        a.innerHTML = HTML;
        // a.appendChild(prepared1);  
        
        console.log(a);
  
        // window.onload=function(){
        for(i=0;i< 18;i++){
          this._shadowRoot.getElementById(i.toString()).addEventListener('click', function () {
            if (this.parentElement.querySelector('.nested') != null) {
              console.log("Hi123");
                this.parentElement.querySelector('.nested').classList.toggle("active");
                if(parseInt(_resultSet[i].l) < parseInt(_resultSet[i+1].l)){
                this.parentElement.querySelector('.nested').className = "active";
                }
                // this.parentElement.querySelector('.nested').setAttribute('class', 'active');

                this.classList.toggle("check-box");
                console.log(a);
            }
          });
          console.log(this._shadowRoot.getElementById(i.toString()).id);
        }

        // for(i=0;i< 18;i++){
        // console.log(this._shadowRoot.getElementById(i.toString()).id);
        // }

        // }
        
      }
  
    }
    customElements.define('com-sap-sample-dd-prepared', SamplePrepared)
  })()