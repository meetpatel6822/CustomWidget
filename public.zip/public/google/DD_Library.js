var getScriptPromisify = (src) => {
    return new Promise(resolve => {
      $.getScript(src, resolve)
    })
  }
  
  (function () {
  
    //Chart Block in HTML
    const prepared = document.createElement('template')
    prepared.innerHTML = `
    <!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <title>DevExtreme Demo</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>window.jQuery || document.write(decodeURIComponent('%3Cscript src="js/jquery.min.js"%3E%3C/script%3E'))</script>
    <link rel="stylesheet" type="text/css" href="https://cdn3.devexpress.com/jslib/21.2.3/css/dx.common.css" />
    <link rel="stylesheet" type="text/css" href="https://cdn3.devexpress.com/jslib/21.2.3/css/dx.light.css" />
    <script src="https://cdn3.devexpress.com/jslib/21.2.3/js/dx.all.js"></script>
    <link rel="stylesheet" type="text/css" href="styles.css" />
    <script src="index.js"></script>
  </head>
  <body class="dx-viewport">
    <div class="demo-container">
      <div id="form">
        <div class="dx-fieldset">
          <div class="dx-field">
            <div class="dx-field-label">DropDownBox with embedded TreeView</div>
            <div class="dx-field-value">
              <div id="treeBox"></div>
            </div>
          </div>
          <div class="dx-field">
            <div class="dx-field-label">DropDownBox with embedded DataGrid</div>
            <div class="dx-field-value">
              <div id="gridBox"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
  
      `
  
    //Main JS Class holds methods to be called
    class SamplePrepared extends HTMLElement {
      constructor() { 
  
        //call SAC DOM Super method to get shadow DOM information
        super()
  
        //Get shadow DOM informations
        this._shadowRoot = this.attachShadow({ mode: 'open' })
        this._shadowRoot.appendChild(prepared.content.cloneNode(true))
  
        //Set HTML block in shadow DOM of SAC
        this._root = this._shadowRoot.getElementById('myUL')
        //_props object is used to hold properties information
        this._props = {}
  
        //Call render() method to plot chart
        this.render(this.resultSet)
      }
  
      //onCustomWidgetResize() method is execute whenever CW will resized in SAC.
      onCustomWidgetResize(width, height) {
  
        //Call render() method to plot chart
        this.render(this.resultSet)
      }
  
      //render() method to plot chart - resultSet1 holds data from SAC table/chart.
      async render(_resultSet) {
  
        await getScriptPromisify('https://cdn3.devexpress.com/jslib/21.2.3/js/dx.all.js');
        await getScriptPromisify('https://cdn3.devexpress.com/jslib/21.2.3/css/dx.light.css');
        await getScriptPromisify('https://cdn3.devexpress.com/jslib/21.2.3/css/dx.common.css');
        await getScriptPromisify('https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js');

        $(() => {
            let treeView; 
            let dataGrid;
          
            const syncTreeViewSelection = function (treeViewInstance, value) {
              if (!value) {
                treeViewInstance.unselectAll();
                return;
              }
          
              value.forEach((key) => {
                treeViewInstance.selectItem(key);
              });
            };
          
            const makeAsyncDataSource = function (jsonFile) {
              return new DevExpress.data.CustomStore({
                loadMode: 'raw',
                key: 'ID',
                load() {
                  return $.getJSON(`https://js.devexpress.com/Demos/WidgetsGallery/JSDemos/data/${jsonFile}`);
                },
              });
            };
          
            $('#treeBox').dxDropDownBox({
              value: ['1_1'],
              valueExpr: 'ID',
              displayExpr: 'name',
              placeholder: 'Select a value...',
              showClearButton: true,
              dataSource: makeAsyncDataSource('treeProducts.json'),
              contentTemplate(e) {
                const v = e.component.option('value');
                const $treeView = $('<div>').dxTreeView({
                  dataSource: e.component.getDataSource(),
                  dataStructure: 'plain',
                  keyExpr: 'ID',
                  parentIdExpr: 'categoryId',
                  selectionMode: 'multiple',
                  displayExpr: 'name',
                  selectByClick: true,
                  onContentReady(args) {
                    syncTreeViewSelection(args.component, v);
                  },
                  selectNodesRecursive: false,
                  showCheckBoxesMode: 'normal',
                  onItemSelectionChanged(args) {
                    const selectedKeys = args.component.getSelectedNodeKeys();
                    e.component.option('value', selectedKeys);
                  },
                });
          
                treeView = $treeView.dxTreeView('instance');
          
                e.component.on('valueChanged', (args) => {
                  const { value } = args;
                  syncTreeViewSelection(treeView, value);
                });
          
                return $treeView;
              },
            });
          
            $('#gridBox').dxDropDownBox({
              value: [3],
              valueExpr: 'ID',
              placeholder: 'Select a value...',
              displayExpr: 'CompanyName',
              showClearButton: true,
              dataSource: makeAsyncDataSource('customers.json'),
              contentTemplate(e) {
                const v = e.component.option('value');
                const $dataGrid = $('<div>').dxDataGrid({
                  dataSource: e.component.getDataSource(),
                  columns: ['CompanyName', 'City', 'Phone'],
                  hoverStateEnabled: true,
                  paging: { enabled: true, pageSize: 10 },
                  filterRow: { visible: true },
                  scrolling: { mode: 'virtual' },
                  height: 345,
                  selection: { mode: 'multiple' },
                  selectedRowKeys: v,
                  onSelectionChanged(selectedItems) {
                    const keys = selectedItems.selectedRowKeys;
                    e.component.option('value', keys);
                  },
                });
          
                dataGrid = $dataGrid.dxDataGrid('instance');
          
                e.component.on('valueChanged', (args) => {
                  const { value } = args;
                  dataGrid.selectRows(value, false);
                });
          
                return $dataGrid;
              },
            });
          });



        
      }
  
    }
    customElements.define('com-sap-sample-dd-prepared', SamplePrepared)
  })()